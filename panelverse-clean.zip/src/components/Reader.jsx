import { useCallback, useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react'
import { COMICS } from '../data/comics'

const variants = {
  enter: (d) => ({ x: d > 0 ? 80 : -80, opacity: 0, scale: 0.98 }),
  center: { x: 0, opacity: 1, scale: 1 },
  exit: (d) => ({ x: d > 0 ? -80 : 80, opacity: 0, scale: 0.98 }),
}

export default function Reader({ comicId, onClose }) {
  const comic = COMICS.find((c) => c.id === comicId)
  const [[page, dir], setPage] = useState([0, 0])
  const total = comic.pages.length
  const Art = comic.pages[page].art

  const go = useCallback(
    (d) => setPage(([p]) => {
      const n = p + d
      return n < 0 || n >= total ? [p, 0] : [n, d]
    }),
    [total],
  )

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'ArrowRight') go(1)
      if (e.key === 'ArrowLeft') go(-1)
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [go, onClose])

  const progress = ((page + 1) / total) * 100

  return (
    <motion.div
      className="fixed inset-0 z-[80] flex flex-col bg-ink text-paper"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 40 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      role="dialog"
      aria-modal="true"
      aria-label={`Reading ${comic.title}`}
    >
      <div className="h-1 w-full bg-paper/15" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress)} aria-label="Reading progress">
        <motion.div className="h-full bg-sun" animate={{ width: `${progress}%` }} transition={{ duration: 0.5 }} />
      </div>

      <header className="flex items-center justify-between gap-4 px-5 py-4 md:px-8">
        <button onClick={onClose} className="inline-flex items-center gap-2 rounded-full border border-paper/25 px-4 py-2 text-sm font-medium transition-colors hover:bg-paper hover:text-ink">
          <ArrowLeft size={16} /> Back to library
        </button>
        <div className="text-center">
          <p className="font-display text-lg font-semibold leading-tight">{comic.title}</p>
          <p className="text-xs text-paper/60">{comic.chapter}</p>
        </div>
        <p className="w-28 text-right text-sm tabular-nums text-paper/70">
          Page {page + 1} / {total}
        </p>
      </header>

      <main className="relative flex min-h-0 flex-1 items-center justify-center px-4 pb-4 md:px-16">
        <button onClick={() => go(-1)} disabled={page === 0} aria-label="Previous page" className="absolute left-3 z-10 hidden rounded-full bg-paper p-3 text-ink transition-opacity hover:bg-sun disabled:opacity-20 md:block">
          <ChevronLeft />
        </button>

        <div className="flex h-full w-full max-w-4xl flex-col items-center justify-center gap-5">
          <AnimatePresence mode="wait" custom={dir}>
            <motion.figure
              key={page}
              custom={dir}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="w-full"
            >
              <div className="mx-auto aspect-[3/2] max-h-[56vh] overflow-hidden rounded-2xl border-4 border-paper shadow-lift">
                <Art />
              </div>
              <figcaption className="mx-auto mt-5 max-w-2xl text-center">
                <span className="font-comic text-xl tracking-widest text-sun">{comic.pages[page].title.toUpperCase()}</span>
                <p className="mt-2 text-base leading-relaxed text-paper/90 md:text-lg">{comic.pages[page].caption}</p>
              </figcaption>
            </motion.figure>
          </AnimatePresence>
        </div>

        <button onClick={() => go(1)} disabled={page === total - 1} aria-label="Next page" className="absolute right-3 z-10 hidden rounded-full bg-paper p-3 text-ink transition-opacity hover:bg-sun disabled:opacity-20 md:block">
          <ChevronRight />
        </button>
      </main>

      <footer className="flex items-center justify-between gap-4 px-5 pb-6 md:justify-center md:gap-8">
        <button onClick={() => go(-1)} disabled={page === 0} className="rounded-full border border-paper/25 px-5 py-2.5 text-sm font-medium transition-colors hover:bg-paper hover:text-ink disabled:opacity-30 md:hidden">
          Previous
        </button>
        <div className="flex items-center gap-2" aria-hidden="true">
          {comic.pages.map((_, i) => (
            <span key={i} className={`h-2 rounded-full transition-all ${i === page ? 'w-8 bg-sun' : 'w-2 bg-paper/30'}`} />
          ))}
        </div>
        {page === total - 1 ? (
          <button onClick={onClose} className="rounded-full bg-sun px-5 py-2.5 text-sm font-semibold text-ink">
            Finish
          </button>
        ) : (
          <button onClick={() => go(1)} className="rounded-full bg-paper px-5 py-2.5 text-sm font-semibold text-ink transition-colors hover:bg-sun md:hidden">
            Next
          </button>
        )}
      </footer>
    </motion.div>
  )
}
