import { motion } from 'framer-motion'
import { ArrowRight, BookOpen } from 'lucide-react'
import { COVERS } from '../art/Covers'

const Float = ({ className, children, delay = 0, amp = 12 }) => (
  <motion.div
    aria-hidden="true"
    className={`absolute ${className}`}
    animate={{ y: [0, -amp, 0], rotate: [0, 4, 0] }}
    transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay }}
  >
    {children}
  </motion.div>
)

const item = (i) => ({
  initial: { opacity: 0, y: 36 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.8, delay: 0.5 + i * 0.12, ease: [0.22, 1, 0.36, 1] },
})

export default function Hero({ onRead }) {
  const Cover = COVERS.guardian
  const Cover2 = COVERS.inventor
  return (
    <section id="home" className="relative overflow-hidden pt-32 md:pt-40">
      <div className="halftone pointer-events-none absolute right-0 top-20 h-96 w-96 opacity-60 [mask-image:radial-gradient(circle,black,transparent_70%)]" />
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 pb-24 md:px-8 lg:grid-cols-2">
        <div className="relative z-10">
          <motion.p {...item(0)} className="mb-5 inline-flex items-center gap-2 rounded-full bg-sun/30 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest">
            <BookOpen size={14} /> Digital comic publication
          </motion.p>
          <motion.h1 {...item(1)} className="font-display text-5xl font-bold leading-[1.02] tracking-tight sm:text-6xl lg:text-7xl">
            Every Panel
            <br />
            Has a <span className="relative inline-block text-flame">Story.
              <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 200 12" fill="none" aria-hidden="true">
                <motion.path d="M2 8 Q50 0 100 6 T198 4" stroke="#FFB703" strokeWidth="5" strokeLinecap="round"
                  initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ delay: 1.2, duration: 0.9 }} />
              </svg>
            </span>
          </motion.h1>
          <motion.p {...item(2)} className="mt-7 max-w-lg text-lg leading-relaxed text-ink/70">
            Discover extraordinary worlds, unforgettable characters, and stories that inspire imagination.
          </motion.p>
          <motion.div {...item(3)} className="mt-9 flex flex-wrap gap-3">
            <a href="#explore" className="btn-primary group">
              Explore Stories
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </a>
            <button onClick={() => onRead('little-inventor')} className="btn-ghost">
              Read Featured Story
            </button>
          </motion.div>
        </div>

        <motion.div
          className="relative mx-auto h-[420px] w-full max-w-md sm:h-[500px]"
          initial={{ opacity: 0, scale: 0.92, rotate: 3 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 1, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="absolute left-0 top-10 h-[380px] w-[240px] -rotate-6 overflow-hidden rounded-3xl border-4 border-ink shadow-lift sm:h-[440px] sm:w-[280px]">
            <Cover2 />
          </div>
          <div className="absolute right-0 top-0 h-[380px] w-[240px] rotate-4 overflow-hidden rounded-3xl border-4 border-ink shadow-lift sm:h-[440px] sm:w-[280px]" style={{ transform: 'rotate(5deg)' }}>
            <Cover />
          </div>
          <Float className="-left-4 top-0" delay={0.2}>
            <span className="block -rotate-12 rounded-xl border-2 border-ink bg-sun px-3 py-1 font-comic text-xl tracking-wider shadow-soft">POW!</span>
          </Float>
          <Float className="-right-2 bottom-10" delay={1} amp={16}>
            <span className="block rotate-6 rounded-full border-2 border-ink bg-paper px-4 py-2 text-sm font-semibold shadow-soft">Once upon a panel…</span>
          </Float>
          <Float className="bottom-0 left-8" delay={0.6} amp={8}>
            <span className="block h-8 w-8 rounded-full bg-grape" />
          </Float>
        </motion.div>
      </div>
    </section>
  )
}
