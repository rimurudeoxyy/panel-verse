import { AnimatePresence, motion } from 'framer-motion'
import { Search, X } from 'lucide-react'
import { CATEGORIES, COMICS } from '../data/comics'
import ComicCard from './ComicCard'
import Reveal from './Reveal'

export default function Library({ category, setCategory, query, setQuery, onRead }) {
  const q = query.trim().toLowerCase()
  const results = COMICS.filter((c) => {
    const inCat = category === 'All' || c.categories.includes(category)
    const inQuery = !q || `${c.title} ${c.genre} ${c.description}`.toLowerCase().includes(q)
    return inCat && inQuery
  })

  return (
    <section id="library" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-20 md:px-8 md:py-28">
      <Reveal>
        <p className="text-xs font-semibold uppercase tracking-widest text-flame">The library</p>
        <h2 className="mt-3 font-display text-4xl font-bold tracking-tight md:text-5xl">All stories.</h2>
      </Reveal>

      <div className="mt-8 flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
          {['All', ...CATEGORIES.map((c) => c.name)].map((name) => (
            <button
              key={name}
              onClick={() => setCategory(name)}
              aria-pressed={category === name}
              className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                category === name ? 'bg-ink text-paper' : 'bg-white text-ink/70 shadow-soft hover:text-ink'
              }`}
            >
              {name}
            </button>
          ))}
        </div>
        <label className="relative block md:w-72">
          <span className="sr-only">Search comics</span>
          <Search size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" />
          <input
            id="library-search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search titles or genres"
            className="w-full rounded-full border-0 bg-white py-3 pl-11 pr-10 text-sm shadow-soft placeholder:text-ink/40"
          />
          {query && (
            <button onClick={() => setQuery('')} aria-label="Clear search" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 hover:bg-cream">
              <X size={14} />
            </button>
          )}
        </label>
      </div>

      <motion.div layout className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {results.map((c, i) => (
            <ComicCard key={c.id} comic={c} index={i} onRead={onRead} />
          ))}
        </AnimatePresence>
      </motion.div>

      {results.length === 0 && (
        <p className="mt-16 text-center text-ink/60">
          No stories match yet.{' '}
          <button className="font-semibold underline" onClick={() => { setCategory('All'); setQuery('') }}>
            Clear filters
          </button>
        </p>
      )}
    </section>
  )
}
