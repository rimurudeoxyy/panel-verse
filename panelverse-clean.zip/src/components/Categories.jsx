import { motion } from 'framer-motion'
import { CATEGORIES } from '../data/comics'
import { CATEGORY_ART } from '../art/CategoryArt'
import Reveal from './Reveal'

export default function Categories({ onPick }) {
  return (
    <section id="categories" className="scroll-mt-20 bg-cream py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <p className="text-xs font-semibold uppercase tracking-widest text-grape">Explore categories</p>
          <h2 className="mt-3 max-w-xl font-display text-4xl font-bold tracking-tight md:text-5xl">
            Pick a world to wander into.
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((c, i) => {
            const Art = CATEGORY_ART[c.name]
            return (
              <Reveal key={c.name} delay={(i % 3) * 0.08}>
                <motion.button
                  onClick={() => onPick(c.name)}
                  whileHover={{ y: -6 }}
                  className="group w-full overflow-hidden rounded-3xl bg-white text-left shadow-soft transition-shadow hover:shadow-lift"
                  aria-label={`Show ${c.name} comics`}
                >
                  <div className="h-40 overflow-hidden">
                    <div className="h-full w-full transition-transform duration-700 group-hover:scale-110">
                      <Art />
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-display text-xl font-semibold">{c.name}</h3>
                    <p className="mt-1 text-sm text-ink/60">{c.blurb}</p>
                  </div>
                </motion.button>
              </Reveal>
            )
          })}
        </div>
      </div>
    </section>
  )
}
