import { Eye, Globe2, Lightbulb } from 'lucide-react'
import Reveal from './Reveal'

const POINTS = [
  { icon: Eye, title: 'Pictures carry meaning', text: 'Visuals and words together help readers understand and remember complex ideas faster.' },
  { icon: Globe2, title: 'Accessible to all', text: 'Short, visual stories lower the barrier for new readers, young learners and second-language speakers.' },
  { icon: Lightbulb, title: 'Curiosity first', text: 'A good story makes people want to learn. Science, history and ethics become adventures.' },
]

export default function About() {
  return (
    <section id="about" className="scroll-mt-20 bg-ink py-20 text-paper md:py-28">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 md:px-8 lg:grid-cols-2">
        <Reveal>
          <p className="text-xs font-semibold uppercase tracking-widest text-sun">About</p>
          <h2 className="mt-3 font-display text-4xl font-bold leading-tight tracking-tight md:text-5xl">
            Stories That Educate and Inspire.
          </h2>
          <p className="mt-6 max-w-lg leading-relaxed text-paper/70">
            PANELVERSE shows how comics make learning more approachable. By pairing illustration with short, clear
            text, each panel turns an idea into something you can see, follow and remember.
          </p>
          <div className="mt-8 inline-flex items-center gap-4 rounded-2xl bg-paper/10 p-4">
            <span className="flex h-14 w-14 items-center justify-center rounded-xl bg-flame font-comic text-xl text-paper">SDG 4</span>
            <p className="max-w-xs text-sm text-paper/80">
              <strong className="text-paper">Quality Education.</strong> Supporting inclusive, accessible learning
              through informal visual storytelling and literacy.
            </p>
          </div>
        </Reveal>

        <div className="space-y-4">
          {POINTS.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.1}>
              <div className="flex gap-4 rounded-3xl bg-paper/5 p-6 transition-colors hover:bg-paper/10">
                <p.icon className="mt-1 shrink-0 text-sun" size={24} />
                <div>
                  <h3 className="font-display text-xl font-semibold">{p.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-paper/65">{p.text}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
