import { COMICS } from '../data/comics'
import ComicCard from './ComicCard'
import Reveal from './Reveal'

export default function Featured({ onRead }) {
  const featured = COMICS.slice(0, 4)
  return (
    <section id="explore" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-20 md:px-8 md:py-28">
      <Reveal>
        <p className="text-xs font-semibold uppercase tracking-widest text-flame">Featured comics</p>
        <h2 className="mt-3 max-w-xl font-display text-4xl font-bold tracking-tight md:text-5xl">
          Four stories to begin with.
        </h2>
      </Reveal>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {featured.map((c, i) => (
          <ComicCard key={c.id} comic={c} index={i} onRead={onRead} />
        ))}
      </div>
    </section>
  )
}
