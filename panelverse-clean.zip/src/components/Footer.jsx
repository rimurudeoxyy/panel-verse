import { Github, Instagram, Twitter, Youtube } from 'lucide-react'

const SOCIAL = [
  { icon: Instagram, label: 'Instagram' },
  { icon: Twitter, label: 'Twitter' },
  { icon: Youtube, label: 'YouTube' },
  { icon: Github, label: 'GitHub' },
]

export default function Footer() {
  return (
    <footer className="bg-ink text-paper">
      <div className="mx-auto max-w-7xl border-t border-paper/10 px-5 py-14 md:px-8">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <p className="font-comic text-3xl tracking-widest">
              PANEL<span className="text-flame">VERSE</span>
            </p>
            <p className="mt-3 max-w-xs text-sm text-paper/60">Every panel has a story. A digital comic publication for curious readers.</p>
          </div>
          <nav aria-label="Footer">
            <p className="text-xs font-semibold uppercase tracking-widest text-paper/50">Quick links</p>
            <ul className="mt-4 space-y-2 text-sm">
              {[['Home', '#home'], ['Explore Comics', '#explore'], ['Categories', '#categories'], ['About', '#about']].map(([l, h]) => (
                <li key={l}><a href={h} className="text-paper/80 transition-colors hover:text-sun">{l}</a></li>
              ))}
            </ul>
          </nav>
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-paper/50">Follow</p>
            <div className="mt-4 flex gap-3">
              {SOCIAL.map(({ icon: Icon, label }) => (
                <a key={label} href="#home" aria-label={label} className="rounded-full border border-paper/20 p-2.5 transition-colors hover:bg-sun hover:text-ink">
                  <Icon size={18} />
                </a>
              ))}
            </div>
            <p className="mt-6 text-sm text-paper/60">Aligned with UN SDG 4 – Quality Education.</p>
          </div>
        </div>
        <p className="mt-12 text-xs text-paper/40">
          © 2026 PANELVERSE · Design Process and Perspective, Assignment 2 · Devan S, S7 CSD, Roll No. 24 · FISAT
        </p>
      </div>
    </footer>
  )
}
