import { motion } from 'framer-motion'

export default function Loader() {
  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-paper"
      exit={{ opacity: 0, transition: { duration: 0.6 } }}
      role="status"
      aria-label="Loading PANELVERSE"
    >
      <div className="flex gap-2">
        {['#FFB703', '#FF6B2C', '#6B4EFF'].map((c, i) => (
          <motion.span
            key={c}
            className="block h-14 w-10 rounded-md border-2 border-ink"
            style={{ background: c }}
            initial={{ y: 0, opacity: 0.3 }}
            animate={{ y: [0, -14, 0], opacity: 1 }}
            transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.15 }}
          />
        ))}
      </div>
      <motion.p
        className="mt-6 font-comic text-3xl tracking-widest"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        PANELVERSE
      </motion.p>
    </motion.div>
  )
}
