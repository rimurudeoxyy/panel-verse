import { motion } from 'framer-motion'
import { Layers } from 'lucide-react'
import { COVERS } from '../art/Covers'

export default function ComicCard({ comic, onRead, index = 0 }) {
  const Cover = COVERS[comic.cover]
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.6, delay: (index % 4) * 0.1, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -8 }}
      className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-soft transition-shadow hover:shadow-lift"
    >
      <button
        onClick={() => onRead(comic.id)}
        aria-label={`Read ${comic.title}`}
        className="relative aspect-[3/4] overflow-hidden"
      >
        <div className="h-full w-full transition-transform duration-700 group-hover:scale-110">
          <Cover />
        </div>
        <span className="absolute left-3 top-3 rounded-full bg-paper/95 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider">
          {comic.genre}
        </span>
      </button>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-xl font-semibold leading-snug">{comic.title}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-ink/65">{comic.description}</p>
        <div className="mt-5 flex items-center justify-between">
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-ink/60">
            <Layers size={14} /> {comic.episodes} episodes
          </span>
          <button onClick={() => onRead(comic.id)} className="btn-primary !px-5 !py-2">
            Read Now
          </button>
        </div>
      </div>
    </motion.article>
  )
}
