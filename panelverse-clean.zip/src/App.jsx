import { useEffect, useState } from 'react'
import { AnimatePresence } from 'framer-motion'
import { Search } from 'lucide-react'
import Loader from './components/Loader'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Featured from './components/Featured'
import Categories from './components/Categories'
import Library from './components/Library'
import About from './components/About'
import Footer from './components/Footer'
import Reader from './components/Reader'
import Modal from './components/Modal'

export default function App() {
  const [loading, setLoading] = useState(true)
  const [reading, setReading] = useState(null)
  const [category, setCategory] = useState('All')
  const [query, setQuery] = useState('')
  const [modal, setModal] = useState(null) // 'search' | 'signin'

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1500)
    return () => clearTimeout(t)
  }, [])

  const pickCategory = (name) => {
    setCategory(name)
    document.getElementById('library')?.scrollIntoView({ behavior: 'smooth' })
  }

  const submitSearch = (e) => {
    e.preventDefault()
    setModal(null)
    setTimeout(() => document.getElementById('library')?.scrollIntoView({ behavior: 'smooth' }), 150)
  }

  return (
    <>
      <AnimatePresence>{loading && <Loader key="loader" />}</AnimatePresence>

      {!loading && (
        <>
          <Navbar onSearch={() => setModal('search')} onSignIn={() => setModal('signin')} />
          <main>
            <Hero onRead={setReading} />
            <Featured onRead={setReading} />
            <Categories onPick={pickCategory} />
            <Library category={category} setCategory={setCategory} query={query} setQuery={setQuery} onRead={setReading} />
            <About />
          </main>
          <Footer />
        </>
      )}

      <AnimatePresence>
        {reading && <Reader key="reader" comicId={reading} onClose={() => setReading(null)} />}
      </AnimatePresence>

      <AnimatePresence>
        {modal === 'search' && (
          <Modal key="search" title="Search comics" onClose={() => setModal(null)}>
            <form onSubmit={submitSearch} className="relative">
              <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Try “space” or “water”"
                className="w-full rounded-full border-0 bg-white py-3 pl-11 pr-4 text-sm shadow-soft"
              />
              <button className="btn-primary mt-4 w-full">Show results</button>
            </form>
          </Modal>
        )}
        {modal === 'signin' && (
          <Modal key="signin" title="Welcome back" onClose={() => setModal(null)}>
            <form onSubmit={(e) => { e.preventDefault(); setModal(null) }} className="space-y-3">
              <label className="block text-sm font-medium">Email
                <input type="email" required className="mt-1 w-full rounded-xl border-0 bg-white px-4 py-3 shadow-soft" />
              </label>
              <label className="block text-sm font-medium">Password
                <input type="password" required className="mt-1 w-full rounded-xl border-0 bg-white px-4 py-3 shadow-soft" />
              </label>
              <button className="btn-primary w-full">Sign In</button>
              <p className="text-center text-xs text-ink/50">Demo only. No data is stored.</p>
            </form>
          </Modal>
        )}
      </AnimatePresence>
    </>
  )
}
