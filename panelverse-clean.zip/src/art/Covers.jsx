// Original hand-built SVG cover illustrations (viewBox 300x400).
const Svg = ({ children, label }) => (
  <svg
    viewBox="0 0 300 400"
    role="img"
    aria-label={label}
    preserveAspectRatio="xMidYMid slice"
    className="h-full w-full"
  >
    {children}
  </svg>
)

export function GuardianCover() {
  return (
    <Svg label="A stone guardian standing before a glowing moon over mountains">
      <rect width="300" height="400" fill="#2A1B5E" />
      <circle cx="150" cy="140" r="90" fill="#FFB703" />
      <circle cx="150" cy="140" r="70" fill="#FFD166" />
      {[...Array(18)].map((_, i) => (
        <circle key={i} cx={(i * 53) % 300} cy={(i * 37) % 120} r="1.6" fill="#FAF6EE" />
      ))}
      <path d="M0 290 L70 190 L120 260 L190 160 L260 250 L300 210 L300 400 L0 400Z" fill="#43308F" />
      <path d="M0 330 L90 250 L150 310 L220 240 L300 320 L300 400 L0 400Z" fill="#14120F" />
      {/* guardian */}
      <g transform="translate(150 250)">
        <rect x="-26" y="-20" width="52" height="86" rx="14" fill="#14120F" />
        <rect x="-18" y="-58" width="36" height="42" rx="12" fill="#14120F" />
        <path d="M-30 -20 L-52 14 L-30 8Z M30 -20 L52 14 L30 8Z" fill="#14120F" />
        <circle cx="-7" cy="-40" r="4" fill="#FF6B2C" />
        <circle cx="7" cy="-40" r="4" fill="#FF6B2C" />
        <path d="M-16 -62 L-10 -80 L-3 -62 M3 -62 L10 -80 L16 -62" fill="#14120F" />
      </g>
      <text x="150" y="60" textAnchor="middle" fontFamily="Bangers, Impact" fontSize="34" fill="#FAF6EE" letterSpacing="2">THE LAST</text>
    </Svg>
  )
}

export function StarsCover() {
  return (
    <Svg label="A small rocket flying past a ringed planet in deep space">
      <rect width="300" height="400" fill="#14120F" />
      {[...Array(40)].map((_, i) => (
        <circle key={i} cx={(i * 71) % 300} cy={(i * 47) % 400} r={i % 5 === 0 ? 2 : 1} fill="#FAF6EE" opacity="0.8" />
      ))}
      <circle cx="210" cy="130" r="62" fill="#FF6B2C" />
      <path d="M170 110 Q210 90 250 120" stroke="#FFB703" strokeWidth="8" fill="none" opacity="0.7" />
      <path d="M160 150 Q210 170 262 142" stroke="#FFB703" strokeWidth="6" fill="none" opacity="0.6" />
      <ellipse cx="210" cy="135" rx="105" ry="16" fill="none" stroke="#FAF6EE" strokeWidth="4" transform="rotate(-18 210 135)" />
      <circle cx="60" cy="300" r="26" fill="#6B4EFF" />
      <circle cx="52" cy="292" r="8" fill="#8F78FF" />
      {/* rocket */}
      <g transform="translate(120 260) rotate(35)">
        <path d="M0 -60 Q26 -30 20 30 L-20 30 Q-26 -30 0 -60Z" fill="#FAF6EE" />
        <circle cx="0" cy="-12" r="10" fill="#6B4EFF" />
        <path d="M-20 14 L-38 40 L-20 30Z M20 14 L38 40 L20 30Z" fill="#FF6B2C" />
        <path d="M-10 30 L0 70 L10 30Z" fill="#FFB703" />
      </g>
      <text x="150" y="365" textAnchor="middle" fontFamily="Bangers, Impact" fontSize="32" fill="#FFB703" letterSpacing="2">BEYOND THE</text>
    </Svg>
  )
}

export function KingdomCover() {
  return (
    <Svg label="A ruined castle in fog beneath a purple sky with a lantern glowing">
      <rect width="300" height="400" fill="#E9DFF9" />
      <rect y="0" width="300" height="400" fill="#6B4EFF" opacity="0.25" />
      <circle cx="230" cy="80" r="34" fill="#FAF6EE" />
      <g fill="#14120F">
        <rect x="70" y="170" width="46" height="170" />
        <rect x="64" y="158" width="58" height="18" />
        <rect x="150" y="210" width="60" height="130" />
        <path d="M150 210 L160 190 L170 210 L180 190 L190 210 L200 190 L210 210Z" />
        <rect x="228" y="240" width="40" height="100" />
        <path d="M70 170 L93 120 L116 170Z" />
        <rect x="86" y="205" width="14" height="26" rx="7" fill="#FFB703" />
      </g>
      <path d="M0 330 Q75 300 150 330 T300 320 L300 400 L0 400Z" fill="#FAF6EE" opacity="0.85" />
      <path d="M0 360 Q80 335 160 360 T300 350 L300 400 L0 400Z" fill="#14120F" />
      <g transform="translate(150 340)">
        <circle r="26" fill="#FFB703" opacity="0.35" />
        <rect x="-8" y="-12" width="16" height="22" rx="3" fill="#FFB703" />
        <path d="M-6 -12 Q0 -26 6 -12" stroke="#FFB703" strokeWidth="3" fill="none" />
      </g>
      <text x="150" y="44" textAnchor="middle" fontFamily="Bangers, Impact" fontSize="30" fill="#14120F" letterSpacing="2">THE FORGOTTEN</text>
    </Svg>
  )
}

export function InventorCover() {
  return (
    <Svg label="A child inventor beside a colourful machine with gears and a light bulb">
      <rect width="300" height="400" fill="#FFB703" />
      <rect y="300" width="300" height="100" fill="#14120F" opacity="0.9" />
      {/* gears */}
      {[[70, 110, 40], [130, 150, 26]].map(([x, y, r], i) => (
        <g key={i} transform={`translate(${x} ${y})`}>
          {[...Array(8)].map((_, k) => (
            <rect key={k} x={-5} y={-r - 8} width="10" height="16" fill="#14120F" transform={`rotate(${k * 45})`} />
          ))}
          <circle r={r} fill="#14120F" />
          <circle r={r * 0.4} fill="#FFB703" />
        </g>
      ))}
      {/* bulb */}
      <g transform="translate(225 90)">
        <circle r="46" fill="#FAF6EE" opacity="0.5" />
        <circle r="26" fill="#FAF6EE" />
        <rect x="-10" y="22" width="20" height="14" rx="3" fill="#14120F" />
        <path d="M-8 -4 L0 12 L8 -4" stroke="#FF6B2C" strokeWidth="3" fill="none" />
      </g>
      {/* kid */}
      <g transform="translate(150 290)">
        <rect x="-26" y="-20" width="52" height="64" rx="14" fill="#6B4EFF" />
        <circle cy="-52" r="30" fill="#F2C9A0" />
        <path d="M-30 -58 Q0 -96 30 -58 Q10 -70 -30 -58Z" fill="#14120F" />
        <circle cx="-10" cy="-52" r="9" fill="#FAF6EE" stroke="#14120F" strokeWidth="3" />
        <circle cx="10" cy="-52" r="9" fill="#FAF6EE" stroke="#14120F" strokeWidth="3" />
        <path d="M-9 -34 Q0 -28 9 -34" stroke="#14120F" strokeWidth="3" fill="none" strokeLinecap="round" />
      </g>
      <text x="150" y="365" textAnchor="middle" fontFamily="Bangers, Impact" fontSize="32" fill="#FAF6EE" letterSpacing="2">THE LITTLE</text>
    </Svg>
  )
}

export const COVERS = {
  guardian: GuardianCover,
  stars: StarsCover,
  kingdom: KingdomCover,
  inventor: InventorCover,
}
