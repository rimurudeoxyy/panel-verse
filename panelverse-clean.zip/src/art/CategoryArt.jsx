// Six small illustrated identities for the category cards (viewBox 240x160).
const Frame = ({ bg, children, label }) => (
  <svg viewBox="0 0 240 160" role="img" aria-label={label} preserveAspectRatio="xMidYMid slice" className="h-full w-full">
    <rect width="240" height="160" fill={bg} />
    {children}
  </svg>
)

const Adventure = () => (
  <Frame bg="#FF6B2C" label="Mountain peaks with a flag">
    <circle cx="190" cy="40" r="20" fill="#FFB703" />
    <path d="M0 160 L70 50 L120 120 L160 70 L240 160Z" fill="#14120F" />
    <path d="M70 50 L55 76 L70 70 L84 78Z" fill="#FAF6EE" />
    <path d="M70 50 V28" stroke="#FAF6EE" strokeWidth="3" />
    <path d="M70 28 L92 35 L70 42Z" fill="#FFB703" />
  </Frame>
)

const SciFi = () => (
  <Frame bg="#14120F" label="Planet with a ring and stars">
    {[...Array(14)].map((_, i) => (
      <circle key={i} cx={(i * 47) % 240} cy={(i * 29) % 160} r="1.5" fill="#FAF6EE" />
    ))}
    <circle cx="120" cy="80" r="36" fill="#6B4EFF" />
    <ellipse cx="120" cy="84" rx="70" ry="12" fill="none" stroke="#FFB703" strokeWidth="5" transform="rotate(-15 120 84)" />
    <circle cx="190" cy="30" r="8" fill="#FF6B2C" />
  </Frame>
)

const Fantasy = () => (
  <Frame bg="#6B4EFF" label="A dragon-like crescent moon and castle">
    <path d="M150 20 A40 40 0 1 0 190 80 A32 32 0 1 1 150 20Z" fill="#FFB703" />
    <g fill="#14120F">
      <rect x="40" y="90" width="30" height="70" />
      <rect x="36" y="82" width="38" height="12" />
      <rect x="80" y="110" width="40" height="50" />
      <path d="M40 90 L55 56 L70 90Z" />
    </g>
    <path d="M120 140 q10 -30 40 -26 q-14 8 -10 26Z" fill="#FAF6EE" opacity="0.8" />
  </Frame>
)

const Mystery = () => (
  <Frame bg="#E9DFF9" label="A magnifying glass over footprints">
    <g fill="#14120F" opacity="0.8">
      <ellipse cx="40" cy="120" rx="7" ry="10" />
      <ellipse cx="66" cy="100" rx="7" ry="10" />
      <ellipse cx="92" cy="122" rx="7" ry="10" />
    </g>
    <circle cx="150" cy="70" r="38" fill="#FAF6EE" stroke="#14120F" strokeWidth="9" />
    <path d="M178 98 L214 140" stroke="#14120F" strokeWidth="12" strokeLinecap="round" />
    <path d="M132 58 Q144 46 160 50" stroke="#FFB703" strokeWidth="5" fill="none" strokeLinecap="round" />
  </Frame>
)

const Educational = () => (
  <Frame bg="#FFB703" label="An open book with a light bulb">
    <path d="M40 120 Q120 100 120 120 Q120 100 200 120 V146 Q120 126 120 146 Q120 126 40 146Z" fill="#14120F" />
    <path d="M50 114 Q120 94 120 114 V136 Q120 116 50 136Z" fill="#FAF6EE" />
    <path d="M190 114 Q120 94 120 114 V136 Q120 116 190 136Z" fill="#F3EDE0" />
    <circle cx="120" cy="52" r="24" fill="#FAF6EE" />
    <rect x="110" y="72" width="20" height="12" rx="3" fill="#14120F" />
    <path d="M112 50 L120 64 L128 50" stroke="#FF6B2C" strokeWidth="3" fill="none" />
  </Frame>
)

const History = () => (
  <Frame bg="#F3EDE0" label="Greek-style columns and a scroll">
    <rect x="30" y="30" width="180" height="14" fill="#14120F" />
    {[50, 95, 140, 185].map((x) => (
      <rect key={x} x={x - 8} y="44" width="16" height="84" fill="#14120F" />
    ))}
    <rect x="22" y="128" width="196" height="14" fill="#FF6B2C" />
    <path d="M30 30 L120 6 L210 30Z" fill="#FFB703" />
  </Frame>
)

export const CATEGORY_ART = {
  Adventure,
  'Science Fiction': SciFi,
  Fantasy,
  Mystery,
  Educational,
  History,
}
