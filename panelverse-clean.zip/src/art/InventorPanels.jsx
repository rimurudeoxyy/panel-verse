// Six illustrated panels for "The Little Inventor" (viewBox 600x400).
const Wrap = ({ children, label, bg }) => (
  <svg viewBox="0 0 600 400" role="img" aria-label={label} preserveAspectRatio="xMidYMid slice" className="h-full w-full">
    <rect width="600" height="400" fill={bg} />
    {children}
  </svg>
)

const Mira = ({ x = 0, y = 0, s = 1, mood = 'smile' }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x="-34" y="-10" width="68" height="96" rx="20" fill="#6B4EFF" />
    <circle cy="-48" r="42" fill="#F2C9A0" />
    <path d="M-44 -54 Q0 -108 44 -54 Q14 -72 -44 -54Z" fill="#14120F" />
    <circle cx="-34" cy="-70" r="12" fill="#14120F" />
    <circle cx="-14" cy="-48" r="12" fill="#FAF6EE" stroke="#14120F" strokeWidth="4" />
    <circle cx="14" cy="-48" r="12" fill="#FAF6EE" stroke="#14120F" strokeWidth="4" />
    <circle cx="-14" cy="-48" r="3.5" fill="#14120F" />
    <circle cx="14" cy="-48" r="3.5" fill="#14120F" />
    {mood === 'smile' ? (
      <path d="M-12 -22 Q0 -10 12 -22" stroke="#14120F" strokeWidth="4" fill="none" strokeLinecap="round" />
    ) : (
      <path d="M-10 -18 Q0 -26 10 -18" stroke="#14120F" strokeWidth="4" fill="none" strokeLinecap="round" />
    )}
  </g>
)

const Bucket = ({ x, y, fill }) => (
  <g transform={`translate(${x} ${y})`}>
    <path d="M-30 0 L-24 56 H24 L30 0Z" fill="#14120F" />
    <ellipse cy="0" rx="30" ry="8" fill={fill} />
    <path d="M-30 0 Q0 -50 30 0" stroke="#14120F" strokeWidth="4" fill="none" />
  </g>
)

export const InventorPanels = [
  // 1 — the problem: muddy well
  () => (
    <Wrap bg="#FFE9A8" label="Mira looks into a bucket of muddy water beside the village well">
      <rect y="300" width="600" height="100" fill="#C98A4B" />
      <circle cx="500" cy="70" r="44" fill="#FFB703" />
      <g transform="translate(400 230)">
        <rect x="-70" y="0" width="140" height="80" rx="8" fill="#14120F" />
        <rect x="-80" y="-14" width="160" height="22" rx="6" fill="#43308F" />
        <path d="M-60 -14 V-90 M60 -14 V-90 M-70 -90 H70" stroke="#14120F" strokeWidth="10" />
      </g>
      <Bucket x={230} y={290} fill="#8B5E34" />
      <Mira x={120} y={250} s={1.1} mood="sad" />
      <path d="M215 190 q10 -16 0 -26 M245 190 q10 -16 0 -26" stroke="#8B5E34" strokeWidth="4" fill="none" strokeLinecap="round" />
    </Wrap>
  ),
  // 2 — idea: lightbulb
  () => (
    <Wrap bg="#E9DFF9" label="Mira has an idea; a light bulb glows above her while a science book lies open">
      <rect y="320" width="600" height="80" fill="#14120F" opacity="0.9" />
      <g transform="translate(300 90)">
        {[...Array(10)].map((_, i) => (
          <rect key={i} x="-3" y="-78" width="6" height="22" rx="3" fill="#FFB703" transform={`rotate(${i * 36})`} />
        ))}
        <circle r="40" fill="#FFB703" />
        <rect x="-14" y="36" width="28" height="18" rx="4" fill="#14120F" />
      </g>
      <Mira x={300} y={290} s={1.2} />
      <path d="M90 330 Q170 300 170 330 Q170 300 250 330 V350 Q170 325 170 350 Q170 325 90 350Z" fill="#FAF6EE" />
      <text x="470" y="150" fontFamily="Bangers, Impact" fontSize="56" fill="#6B4EFF" transform="rotate(-8 470 150)">AHA!</text>
    </Wrap>
  ),
  // 3 — gathering materials
  () => (
    <Wrap bg="#CFF1E3" label="Mira lines up gravel, sand and charcoal on a wooden bench">
      <rect y="250" width="600" height="150" fill="#C98A4B" />
      {[
        { x: 140, c: '#8C8C8C', t: 'GRAVEL' },
        { x: 290, c: '#E8D29A', t: 'SAND' },
        { x: 440, c: '#14120F', t: 'CHARCOAL' },
      ].map((m) => (
        <g key={m.t} transform={`translate(${m.x} 250)`}>
          <path d="M-46 -60 H46 V30 Q46 44 32 44 H-32 Q-46 44 -46 30Z" fill="#FAF6EE" stroke="#14120F" strokeWidth="5" />
          <path d="M-42 -20 H42 V30 Q42 40 32 40 H-32 Q-42 40 -42 30Z" fill={m.c} />
          <text y="82" textAnchor="middle" fontFamily="Bangers, Impact" fontSize="22" fill="#14120F" letterSpacing="1">{m.t}</text>
        </g>
      ))}
      <Mira x={540} y={210} s={0.7} />
    </Wrap>
  ),
  // 4 — building the filter
  () => (
    <Wrap bg="#FFD9C2" label="A layered bottle filter with gravel, sand and charcoal above a clean cup">
      <rect y="330" width="600" height="70" fill="#14120F" opacity="0.9" />
      <g transform="translate(300 40)">
        <path d="M-70 0 H70 L40 190 H-40Z" fill="#FAF6EE" stroke="#14120F" strokeWidth="6" />
        <path d="M-60 40 H60 L52 90 H-52Z" fill="#8C8C8C" />
        <path d="M-52 90 H52 L46 130 H-46Z" fill="#E8D29A" />
        <path d="M-46 130 H46 L40 188 H-40Z" fill="#14120F" />
        <rect x="-6" y="190" width="12" height="30" fill="#14120F" />
        <circle cy="236" r="6" fill="#6BB8FF" />
      </g>
      <Bucket x={120} y={270} fill="#8B5E34" />
      <path d="M170 262 Q220 200 260 90" stroke="#8B5E34" strokeWidth="6" fill="none" strokeDasharray="10 8" />
      <g transform="translate(300 330)">
        <path d="M-30 -50 L-24 0 H24 L30 -50Z" fill="#FAF6EE" stroke="#14120F" strokeWidth="5" />
        <path d="M-27 -20 L-24 0 H24 L27 -20Z" fill="#6BB8FF" />
      </g>
      <Mira x={480} y={290} s={1} />
    </Wrap>
  ),
  // 5 — testing
  () => (
    <Wrap bg="#E1F0FF" label="Clear water drips from the filter while villagers watch in surprise">
      <rect y="320" width="600" height="80" fill="#14120F" opacity="0.9" />
      <g transform="translate(300 60)">
        <path d="M-60 0 H60 L36 150 H-36Z" fill="#FAF6EE" stroke="#14120F" strokeWidth="6" />
        <path d="M-52 30 H52 L36 148 H-36Z" fill="#6BB8FF" opacity="0.7" />
        <path d="M0 150 V240" stroke="#6BB8FF" strokeWidth="8" strokeDasharray="14 10" strokeLinecap="round" />
      </g>
      <g transform="translate(300 330)">
        <path d="M-36 -60 L-28 0 H28 L36 -60Z" fill="#FAF6EE" stroke="#14120F" strokeWidth="5" />
        <path d="M-32 -30 L-28 0 H28 L32 -30Z" fill="#6BB8FF" />
      </g>
      <Mira x={120} y={290} s={1.1} />
      <Mira x={480} y={290} s={0.9} />
      <text x="90" y="110" fontFamily="Bangers, Impact" fontSize="46" fill="#FF6B2C" transform="rotate(-6 90 110)">PLINK!</text>
    </Wrap>
  ),
  // 6 — the village celebrates
  () => (
    <Wrap bg="#FFB703" label="The whole village celebrates around a clean well while Mira holds up a glass of water">
      <circle cx="300" cy="360" r="260" fill="#FF6B2C" opacity="0.3" />
      {[...Array(14)].map((_, i) => (
        <rect key={i} x={(i * 83) % 600} y={(i * 59) % 200} width="12" height="12" rx="3" fill={['#6B4EFF', '#FAF6EE', '#14120F'][i % 3]} transform={`rotate(${i * 25} ${(i * 83) % 600} ${(i * 59) % 200})`} />
      ))}
      <rect y="330" width="600" height="70" fill="#14120F" opacity="0.9" />
      <Mira x={300} y={290} s={1.3} />
      <g transform="translate(375 200)">
        <path d="M-22 -40 L-16 10 H16 L22 -40Z" fill="#FAF6EE" stroke="#14120F" strokeWidth="4" />
        <path d="M-19 -18 L-16 10 H16 L19 -18Z" fill="#6BB8FF" />
      </g>
      <Mira x={110} y={300} s={0.85} />
      <Mira x={500} y={300} s={0.85} />
      <text x="300" y="70" textAnchor="middle" fontFamily="Bangers, Impact" fontSize="64" fill="#14120F" letterSpacing="3">CLEAN WATER!</text>
    </Wrap>
  ),
]
