import { COVERS } from '../art/Covers'
import { InventorPanels } from '../art/InventorPanels'

export const CATEGORIES = [
  { name: 'Adventure', blurb: 'Quests, maps and daring journeys.' },
  { name: 'Science Fiction', blurb: 'Futures, galaxies and big ideas.' },
  { name: 'Fantasy', blurb: 'Magic, myths and ancient guardians.' },
  { name: 'Mystery', blurb: 'Clues, secrets and strange shadows.' },
  { name: 'Educational', blurb: 'Learn something, one panel at a time.' },
  { name: 'History', blurb: 'The past, retold in pictures.' },
]

const preview = (cover, items) =>
  items.map(([caption, title]) => ({ art: COVERS[cover], title, caption }))

export const COMICS = [
  {
    id: 'last-guardian',
    title: 'The Last Guardian',
    cover: 'guardian',
    genre: 'Adventure / Fantasy',
    categories: ['Adventure', 'Fantasy'],
    episodes: 12,
    accent: '#6B4EFF',
    description: 'A stone sentinel wakes after a thousand years to protect a world that has forgotten him.',
    chapter: 'Chapter 1 · The Awakening',
    pages: preview('guardian', [
      ['Beneath the silent mountains, something ancient opened its glowing eyes.', 'The Awakening'],
      ['The village had no name for him. Only a story told to frighten children.', 'A Forgotten Name'],
      ['But when the moon turned gold, the guardian rose to keep his oath once more.', 'The Oath'],
    ]),
  },
  {
    id: 'beyond-the-stars',
    title: 'Beyond the Stars',
    cover: 'stars',
    genre: 'Science Fiction',
    categories: ['Science Fiction', 'Adventure'],
    episodes: 8,
    accent: '#FF6B2C',
    description: 'A lone pilot follows a mysterious signal past the edge of the charted galaxy.',
    chapter: 'Chapter 1 · The Signal',
    pages: preview('stars', [
      ['Pilot Ira Venn heard it first: three pulses, repeating, from beyond the rings.', 'The Signal'],
      ['The map ended here. Her ship, the Kite, did not care.', 'Off the Map'],
      ['Something out there was waiting, and it had been waiting a very long time.', 'Waiting'],
    ]),
  },
  {
    id: 'forgotten-kingdom',
    title: 'The Forgotten Kingdom',
    cover: 'kingdom',
    genre: 'Mystery',
    categories: ['Mystery', 'History'],
    episodes: 10,
    accent: '#14120F',
    description: 'Every night a single lantern lights inside a castle that fell centuries ago. Who keeps it burning?',
    chapter: 'Chapter 1 · The Lantern',
    pages: preview('kingdom', [
      ['The ruins sat silent in the fog, as they had for four hundred years.', 'The Ruins'],
      ['Yet on the third night, young archivist Noor saw a light in the tower.', 'The Light'],
      ['Someone, or something, was still keeping watch over the kingdom.', 'Watcher'],
    ]),
  },
  {
    id: 'little-inventor',
    title: 'The Little Inventor',
    cover: 'inventor',
    genre: 'Educational / Science',
    categories: ['Educational', 'Adventure'],
    episodes: 6,
    accent: '#FFB703',
    featured: true,
    description: 'Mira uses gravel, sand and charcoal to turn muddy well water clean, and learns how filtration works.',
    chapter: 'Chapter 1 · The Muddy Well',
    pages: [
      { art: InventorPanels[0], title: 'The Muddy Well', caption: 'In Mira’s village, the well water had turned brown. Nobody could drink it safely.' },
      { art: InventorPanels[1], title: 'An Idea', caption: 'Mira remembered her science book: water can be cleaned by passing through layers. Different layers catch different things!' },
      { art: InventorPanels[2], title: 'The Ingredients', caption: 'Gravel catches the big bits. Sand traps the finer dirt. Charcoal soaks up smells and tastes.' },
      { art: InventorPanels[3], title: 'Building the Filter', caption: 'She stacked them in a bottle: gravel on top, then sand, then charcoal at the bottom, and poured the muddy water in.' },
      { art: InventorPanels[4], title: 'The Test', caption: 'Drip by drip, the water came out clearer. (Note: filtered water still needs boiling before drinking!)' },
      { art: InventorPanels[5], title: 'A Village Celebrates', caption: 'Mira taught everyone how to build one. Curiosity had changed her whole village.' },
    ],
  },
  {
    id: 'sunken-library',
    title: 'The Sunken Library',
    cover: 'kingdom',
    genre: 'History / Mystery',
    categories: ['History', 'Mystery'],
    episodes: 5,
    accent: '#6B4EFF',
    description: 'Scholars uncover a library lost under the sea and the stories it still whispers.',
    chapter: 'Chapter 1 · Beneath the Waves',
    pages: preview('kingdom', [
      ['The divers expected stone. They found shelves, and every shelf was full.', 'Beneath the Waves'],
      ['History is not only kings and wars. It is also the people who wrote it down.', 'Written Down'],
    ]),
  },
  {
    id: 'orbit-academy',
    title: 'Orbit Academy',
    cover: 'stars',
    genre: 'Science Fiction / Educational',
    categories: ['Science Fiction', 'Educational'],
    episodes: 7,
    accent: '#FF6B2C',
    description: 'Students on a space station learn physics the hard way: by floating through it.',
    chapter: 'Chapter 1 · Zero Gravity',
    pages: preview('stars', [
      ['Lesson one: when you push off a wall in space, the wall pushes back.', 'Zero Gravity'],
      ['Newton would have loved the cafeteria.', 'Newton’s Cafeteria'],
    ]),
  },
]

export const getCover = (key) => COVERS[key]
